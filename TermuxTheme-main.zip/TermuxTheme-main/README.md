<p align="center">
<a href="https://bajetech.org/"><img title="MADE IN NIGERIA" src="https://img.shields.io/badge/-MADE%20IN%20NIGERIA-green%2Cwhite%2Cgreen"></a>
</p>
<p align="center">
<a href="https://bajetech.org/"><img title="MADE IN NIGERIA" src="https://img.shields.io/badge/Termux-Theme-green.svg"></a>
<a href="https://bajetech.org/"><img title="Version" src="https://img.shields.io/badge/Version-1.5-green.svg?style=flat-square"></a>

</p>
<p align="center">
<a href="https://bajetech.org/"><img title="Termux-Theme" src="https://1.bp.blogspot.com/-lyW6zU967fQ/YCLR5v9IqaI/AAAAAAAAAK8/h24GbpmFmjAkZmYE4t6ZKlFAHiE2OU2lQCLcBGAsYHQ/s1280/20210209_191606_0000.png"></a>
</p>
<p align="center">
<a href="https://github.com/AliByte01"><img title="Github" src="https://img.shields.io/badge/Github-AliByte01-brightgreen?style=for-the-badge&logo=github"></a>
<img title="YouTube" src="https://img.shields.io/badge/YouTube-BajeTech-red?style=for-the-badge&logo=Youtube"></a>

## What's this used for?
TermuxTheme, this is one of the best Termux themer that used to switch Termux from black and white into colorfully mode of hackers, one of the best thing with this tool is that as we all know most of the Termux color tools has some ERROS which while typing commands they just keep repeating by going back however this is very useless so, you can use this tool and it will never repeating your typing or get back confirmed InshaAllah.

## AVAILABLE ON :
* Termux Only

## TESTED ON :
* Termux Only.
* Not Working On Others Like Kali Linux,ParrotSec,Ubuntu etc.
*
* DONATE ME TO MAKE IT BE AVAILABLE ON ANY OS.

### THE TOOL REQUIREMENTS:
* Termux From Fdroid
* mpv the will install auto
* python3, pip, lolcat, figlet


## INSTALLATION ON [Termux] :

* `pkg update -y`
* `pkg upgrade -y`
* `pkg install git -y`
```
git clone https://github.com/AliByte01/TermuxTheme
```
* `cd TermuxTheme`
* `chmod 777 *`
* `./setup`
* `ls`
* `./TermuxTheme.sh`



```
THIS TOOL IS CREATED AND MAINTAINED BY AliByte01 AND WILL KEEP UPDATING ALMOST ANYTIME AS WELL AS YOU WILL HOPEFULLY KEEP DONATING TO US.
```


## WHAT'S NEW WITH THIS VERSION 1.7
* FIXED ISSUES IN VERSION 1.5
* HACK BOX THEME UPDATED
* EXCAFE BOX FIGLET WITH LOLCAT FIXED
* COWSAY EYES WITH BOW COW UPDATED
* TOILET ERRORS ALWAYS IS FIXED NOW
* ALWAYS NOT TAKING MANY TIMES TO INSTALL


## WHAT'S FIXED IN THIS VERSION 1.5
```
IN THE PREVIOUS VERSION AS YOU KNOW WHILE RUNNING THE TermuxTheme.sh FILE YOU ARE FACING ERROR FROM LINE 30,32 AND 33 WHICH IS ACTUALLY LOLCAT WRITING MISTAKE, SO THIS ISSUE IS FIXED NOW AND ANY OTHER ERROS SUCH AS mpv ERRORS AND e.t.c IS FIXED NOW AND CONFIRMED INSHAALLAH.
```

## USAGE
* ./TermuxTheme.sh

## SCREENSHOTS [Termux]

<br>
<p align="center">
<img width="80%" src="https://github.com/AliByte01/TermuxTheme/blob/main/code/Screenshot_20220529-162915.png"/>
<img width="80%" src="https://github.com/AliByte01/TermuxTheme/blob/main/code/Screenshot_20220529-162924.png"/>
<img width="80%" src="https://github.com/AliByte01/TermuxTheme/blob/main/code/Screenshot_20220529-162952.png"/>
</p>


## CAUTION!: 
***THIS TOOL ONLY MADE FOR TERMUX BY NOW AND IT'S TO JUST MAKE THE TERMUX COLOR TO BE REALLY AWESOME.***



## Credits
* Thanks To Noob-Hackers
* Thanks To AliByte01


## DONATION
* Smartchain (BNB) BEP20 NETWORK Donation Address👇

```
0x4Bc302A6755ED2B4D2311578d62B59f455E31152
```

* Solana (SOL) Network Solana Donation Address 👇
```
FnF7MWm6YpXygBZNWCun4qZA9VNiqnVnhC5na1MjVfFP
```

## Peoples who donated
*  Thanks to Mr Bilal
*  Thanks to Mr Rabi
*  Thanks to Mrs Ushiya

## These People are the one who helps to update the script and you can also donate to improve the projects and push it to the highest level.

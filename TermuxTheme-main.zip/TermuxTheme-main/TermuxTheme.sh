#!/bin/bash
# Coded by AliByte01
# Created since on 10/02/2021 made in Nigeria by AliByte01.
# If You Take Money For This Little Bash Script Please Look At Your Self Again And Shame on You.
# visit our website https://bajetech.org
clear
sleep 0.5
echo ""
echo "  [VISIT https://bajetech.org TO LEARN MORE]"|lolcat
echo "    _____   _____ _   _ _____ __  __ _____"|lolcat
echo "   |_   _| |_   _| | | | ____|  \/  | ____|"|lolcat
echo "     | |_____| | | |_| |  _| | |\/| |  _|"  |lolcat
echo "     | |_____| | |  _  | |___| |  | | |___" |lolcat
echo "     |_|     |_| |_| |_|_____|_|  |_|_____| V1.5"|lolcat
echo "     [CREATED BY: AliByte01]"|lolcat
sleep 0.5
echo ""
echo "You Are About To Switch Termux To Colorfull Mode."|lolcat
read -p 'Press Enter To Continue Or Press CTRL + Z To Cancel'
echo ""
echo ""
sleep 0.5
echo "Ok Your Termux Theme Will Change Now"|lolcat
sleep 2.0
echo " Please Wait For 10 Seconds To Make The Changes..."|lolcat
sleep 2.0
cd
cd /$HOME
rm //data/data/com.termux/files/usr/etc/bash.bashrc
cd
mv /data/data/com.termux/files/home/TermuxTheme/code/bash.bashrc //data/data/com.termux/files/usr/etc/bash.bashrc
sleep 8.0
echo "Completed, Your Termux Now Looking Awesome"|lolcat
sleep 1.0
echo ""
echo ""
echo "Please exit from the termux and open it again to see the changes."|lolcat
echo "IF YOU ARE INTERESTED IN DONATION"|lolcat
echo "YOU CAN DONATE SOME SMALL AMOUNT OF EITHER"|lolcat
echo "SmartChain (BNB) OR SOLANA TO ME FROM THE"|lolcat
echo "MENTIONED ADDRESSES AND THEIRS NETWORKS BELOW."|lolcat
echo ""
echo "SmartChain (BNB) BEP20 Address👇"|lolcat
echo "NETWORK BNB BEP20: 0x4Bc302A6755ED2B4D2311578d62B59f455E31152"
echo ""
echo "Solana (SOL) SOLANA Address👇"|lolcat
echo "NETWORK SOLOANA: FnF7MWm6YpXygBZNWCun4qZA9VNiqnVnhC5na1MjVfFP"
echo ""
echo ""
echo "VISIT https://bajetech.org TO LEARN MORE."
